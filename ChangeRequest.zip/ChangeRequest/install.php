<?php
/**
 * install.php - run ONCE in the browser: http://localhost/ChangeRequest/install.php
 * Creates the database, tables, a default admin account and sample data.
 */
require __DIR__ . '/database.php';

$log = [];
try {
    $pdo = new PDO('mysql:host=' . DB_HOST . ';charset=utf8mb4', DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $pdo->exec('CREATE DATABASE IF NOT EXISTS `' . DB_NAME . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
    $pdo->exec('USE `' . DB_NAME . '`');
    $log[] = 'Database "' . DB_NAME . '" is ready.';

    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        full_name VARCHAR(100) NOT NULL,
        email VARCHAR(150) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        role ENUM('admin','user') NOT NULL DEFAULT 'user',
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB");

    $pdo->exec("CREATE TABLE IF NOT EXISTS change_requests (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        reference_no VARCHAR(20) NULL UNIQUE,
        title VARCHAR(150) NOT NULL,
        description TEXT NOT NULL,
        reason TEXT NULL,
        impact_analysis TEXT NULL,
        change_type ENUM('Standard','Normal','Emergency') NOT NULL DEFAULT 'Normal',
        priority ENUM('Low','Medium','High','Critical') NOT NULL DEFAULT 'Medium',
        status ENUM('Draft','Submitted','Under Review','Approved','Rejected','Implemented','Closed') NOT NULL DEFAULT 'Draft',
        requested_by VARCHAR(100) NOT NULL,
        requester_email VARCHAR(150) NOT NULL,
        requested_date DATE NOT NULL,
        planned_date DATE NULL,
        created_by INT UNSIGNED NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_status_priority (status, priority),
        CONSTRAINT fk_cr_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
    ) ENGINE=InnoDB");
    $log[] = 'Tables "users" and "change_requests" are ready.';

    if ((int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn() === 0) {
        $st = $pdo->prepare('INSERT INTO users (full_name, email, password, role) VALUES (?,?,?,?)');
        $st->execute(['Administrator', 'admin@example.com', password_hash('admin123', PASSWORD_DEFAULT), 'admin']);
        $st->execute(['Luyanda Kunene', 'luyanda@example.com', password_hash('user123', PASSWORD_DEFAULT), 'user']);
        $log[] = 'Created users: admin@example.com / admin123 (admin) and luyanda@example.com / user123 (user).';
    }

    if ((int)$pdo->query('SELECT COUNT(*) FROM change_requests')->fetchColumn() === 0) {
        $samples = [
            ['Upgrade database server to MySQL 8.4', 'Standard', 'High', 'Approved', 'Thandi Nkosi'],
            ['Emergency patch for login vulnerability', 'Emergency', 'Critical', 'Implemented', 'Peter Naidoo'],
            ['Add multi-factor authentication to staff portal', 'Normal', 'High', 'Under Review', 'Amina Patel'],
            ['Migrate file server to cloud storage', 'Normal', 'Medium', 'Submitted', 'Sipho Dlamini'],
            ['Replace core network switch in server room', 'Normal', 'High', 'Approved', 'Rahul Mehta'],
            ['Update SSL certificate for main website', 'Standard', 'Medium', 'Closed', 'Lerato Mokoena'],
            ['Change backup schedule from weekly to daily', 'Standard', 'Medium', 'Draft', 'Zanele Khumalo'],
            ['Fix payroll report calculation error', 'Emergency', 'Critical', 'Approved', 'John Smith'],
            ['Install new antivirus on all lab computers', 'Standard', 'Low', 'Implemented', 'Fatima Hassan'],
            ['Redesign student registration form', 'Normal', 'Low', 'Draft', 'Kabelo Sithole'],
            ['Increase email attachment size limit', 'Standard', 'Low', 'Rejected', 'Nomsa Zulu'],
            ['Move ERP system to new application server', 'Normal', 'High', 'Under Review', 'David Chen'],
        ];
        $adminId = (int)$pdo->query("SELECT id FROM users WHERE role='admin' LIMIT 1")->fetchColumn();
        $ins = $pdo->prepare('INSERT INTO change_requests (title, description, reason, impact_analysis, change_type, priority, status,
                              requested_by, requester_email, requested_date, planned_date, created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)');
        $upd = $pdo->prepare('UPDATE change_requests SET reference_no = ? WHERE id = ?');
        foreach ($samples as $i => [$title, $type, $prio, $status, $who]) {
            $req = date('Y-m-d', strtotime('-' . (20 - $i) . ' days'));
            $plan = date('Y-m-d', strtotime($req . ' +' . (7 + $i) . ' days'));
            $email = strtolower(str_replace(' ', '.', $who)) . '@example.com';
            $ins->execute([$title, $title . '. Work will be carried out by the IT team during the agreed maintenance window.',
                'Required to keep systems secure, supported and reliable.', 'Short downtime possible; users will be informed in advance.',
                $type, $prio, $status, $who, $email, $req, $plan, $adminId]);
            $id = (int)$pdo->lastInsertId();
            $upd->execute(['CR-' . str_pad((string)$id, 4, '0', STR_PAD_LEFT), $id]);
        }
        $log[] = 'Inserted ' . count($samples) . ' sample change requests.';
    }
    $ok = true;
} catch (PDOException $e) {
    $ok = false;
    $log[] = 'ERROR: ' . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><title>Install</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body class="bg-light"><div class="container py-5" style="max-width:700px">
<div class="card shadow-sm"><div class="card-body">
<h3><?= $ok ? 'Installation complete' : 'Installation failed' ?></h3>
<ul><?php foreach ($log as $l): ?><li><?= e($l) ?></li><?php endforeach; ?></ul>
<?php if ($ok): ?><a class="btn btn-primary" href="login.php">Go to Login</a>
<p class="text-muted small mt-3 mb-0">For safety, delete install.php after the first run.</p>
<?php else: ?><p>Make sure MySQL is started in Laragon, then refresh this page.</p><?php endif; ?>
</div></div></div></body></html>
