<?php
require __DIR__ . '/database.php';
require_login();

$id = (int)($_GET['id'] ?? 0);
$st = db()->prepare('SELECT c.*, u.full_name AS creator FROM change_requests c LEFT JOIN users u ON u.id = c.created_by WHERE c.id = ?');
$st->execute([$id]);
$cr = $st->fetch();
if (!$cr) { flash('danger', 'Change request not found.'); redirect('index.php'); }

$fmt = fn($d) => $d ? date('d M Y', strtotime($d)) : '-';
$pageTitle = $cr['reference_no'];
require __DIR__ . '/includes/header.php';
?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h2 class="fw-bold mb-0"><span class="text-primary"><?= e($cr['reference_no']) ?></span> &ndash; <?= e($cr['title']) ?></h2>
    <span class="fs-5"><?= status_badge($cr['status']) ?></span>
</div>
<div class="card card-soft">
    <div class="card-body p-4">
        <dl class="row mb-0 detail-list">
            <dt class="col-sm-3">Description</dt><dd class="col-sm-9"><?= nl2br(e($cr['description'])) ?></dd>
            <dt class="col-sm-3">Reason for change</dt><dd class="col-sm-9"><?= $cr['reason'] ? nl2br(e($cr['reason'])) : '-' ?></dd>
            <dt class="col-sm-3">Impact analysis</dt><dd class="col-sm-9"><?= $cr['impact_analysis'] ? nl2br(e($cr['impact_analysis'])) : '-' ?></dd>
            <dt class="col-sm-3">Type</dt><dd class="col-sm-9"><?= type_badge($cr['change_type']) ?></dd>
            <dt class="col-sm-3">Priority</dt><dd class="col-sm-9"><?= priority_badge($cr['priority']) ?></dd>
            <dt class="col-sm-3">Requested by</dt><dd class="col-sm-9"><?= e($cr['requested_by']) ?> (<?= e($cr['requester_email']) ?>)</dd>
            <dt class="col-sm-3">Requested date</dt><dd class="col-sm-9"><?= e($fmt($cr['requested_date'])) ?></dd>
            <dt class="col-sm-3">Planned date</dt><dd class="col-sm-9"><?= e($fmt($cr['planned_date'])) ?></dd>
            <dt class="col-sm-3">Created by</dt><dd class="col-sm-9"><?= e($cr['creator'] ?? 'Unknown') ?> on <?= e(date('d M Y, H:i', strtotime($cr['created_at']))) ?></dd>
            <dt class="col-sm-3">Last updated</dt><dd class="col-sm-9"><?= e(date('d M Y, H:i', strtotime($cr['updated_at']))) ?></dd>
        </dl>
    </div>
</div>
<div class="mt-3 d-flex gap-2">
    <a href="index.php" class="btn btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Back</a>
    <?php if (can_modify($cr)): ?>
        <a href="edit.php?id=<?= (int)$cr['id'] ?>" class="btn btn-primary"><i class="bi bi-pencil me-1"></i>Edit</a>
        <form method="post" action="delete.php" data-confirm="Delete <?= e($cr['reference_no']) ?>? This cannot be undone.">
            <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$cr['id'] ?>">
            <button class="btn btn-danger"><i class="bi bi-trash me-1"></i>Delete</button>
        </form>
    <?php endif; ?>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
