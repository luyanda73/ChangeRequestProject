# Change Request System (PHP + MySQL)

**Student:** Luyanda Kunene (92400527009) | **Guide:** Sanket Jethava | BCA 2026-27, Marwadi University

A simple web application to create, view, search, edit and delete change requests, with user login.

## Run with Laragon
1. Copy the `ChangeRequest` folder to `C:\laragon\www\`
2. Open Laragon -> **Start All** (Apache + MySQL).
3. Open **http://localhost/ChangeRequest/install.php** once. It creates the database, tables, two users and sample data.
4. Open **http://localhost/ChangeRequest/login.php** and log in:
   - Admin: `admin@example.com` / `admin123`
   - User: `luyanda@example.com` / `user123`

If your MySQL has a password, change `DB_PASS` in `database.php`.

## Folder structure
```
ChangeRequest/
  index.php      list + search + filters + pagination
  login.php      login          register.php  sign up      logout.php
  create.php  edit.php  view.php  delete.php
  database.php   settings, PDO connection, helpers, validation
  install.php    one-time setup (delete after first run)
  includes/      header.php, footer.php, form.php
  css/ js/ images/
```

## Features
- Login / logout / register (passwords hashed with `password_hash`)
- Full CRUD with server-side validation
- Search by title, reference number, requester; filter by status, priority, type
- Admin can edit/delete everything; normal users only their own requests
- CSRF protection on all forms, prepared statements (PDO) against SQL injection

## GitHub
```
git init
git add .
git commit -m "Change Request System"
git branch -M main
git remote add origin https://github.com/<username>/ChangeRequest.git
git push -u origin main
```
