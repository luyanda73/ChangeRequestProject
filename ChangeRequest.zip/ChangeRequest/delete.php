<?php
require __DIR__ . '/database.php';
require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect('index.php');
csrf_check();

$id = (int)($_POST['id'] ?? 0);
$st = db()->prepare('SELECT * FROM change_requests WHERE id = ?');
$st->execute([$id]);
$cr = $st->fetch();

if (!$cr) {
    flash('danger', 'Change request not found.');
} elseif (!can_modify($cr)) {
    flash('danger', 'You can only delete your own requests.');
} else {
    db()->prepare('DELETE FROM change_requests WHERE id = ?')->execute([$id]);
    flash('success', $cr['reference_no'] . ' deleted.');
}
redirect('index.php');
