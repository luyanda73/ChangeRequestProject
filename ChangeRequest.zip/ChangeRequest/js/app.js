// Confirm before submitting any form that has a data-confirm message
document.querySelectorAll('form[data-confirm]').forEach(function (f) {
    f.addEventListener('submit', function (e) {
        if (!confirm(f.dataset.confirm)) e.preventDefault();
    });
});

// Show / hide password on the login page
var tp = document.getElementById('togglePw');
if (tp) {
    tp.addEventListener('click', function () {
        var pw = document.getElementById('password');
        pw.type = pw.type === 'password' ? 'text' : 'password';
        tp.querySelector('i').className = pw.type === 'password' ? 'bi bi-eye' : 'bi bi-eye-slash';
    });
}

// Hide success messages automatically
document.querySelectorAll('.auto-dismiss.alert-success').forEach(function (a) {
    setTimeout(function () { a.classList.remove('show'); setTimeout(function () { a.remove(); }, 300); }, 4000);
});
