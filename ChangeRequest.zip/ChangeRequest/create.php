<?php
require __DIR__ . '/database.php';
require_login();

$errors = [];
$cr = ['change_type' => 'Normal', 'priority' => 'Medium', 'status' => 'Draft',
       'requested_date' => date('Y-m-d'), 'requested_by' => current_user()['full_name'], 'requester_email' => current_user()['email']];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    [$errors, $cr] = validate_cr($_POST);
    if (!$errors) {
        $pdo = db();
        $st = $pdo->prepare('INSERT INTO change_requests (title, description, reason, impact_analysis, change_type, priority, status,
                             requested_by, requester_email, requested_date, planned_date, created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)');
        $st->execute([$cr['title'], $cr['description'], $cr['reason'] ?: null, $cr['impact_analysis'] ?: null, $cr['change_type'],
                      $cr['priority'], $cr['status'], $cr['requested_by'], $cr['requester_email'], $cr['requested_date'],
                      $cr['planned_date'] ?: null, current_user()['id']]);
        $id = (int)$pdo->lastInsertId();
        $ref = 'CR-' . str_pad((string)$id, 4, '0', STR_PAD_LEFT);
        $pdo->prepare('UPDATE change_requests SET reference_no = ? WHERE id = ?')->execute([$ref, $id]);
        flash('success', "Change request $ref created successfully.");
        redirect('view.php?id=' . $id);
    }
}

$pageTitle = 'New Change Request';
$action = 'create.php';
$submitLabel = 'Save Request';
require __DIR__ . '/includes/header.php';
?>
<h2 class="fw-bold mb-3"><i class="bi bi-plus-circle me-2 text-primary"></i>New Change Request</h2>
<?php require __DIR__ . '/includes/form.php'; ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
