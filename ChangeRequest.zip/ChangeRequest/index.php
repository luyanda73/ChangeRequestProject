<?php
require __DIR__ . '/database.php';
require_login();

/* ----- read filters ----- */
$search   = trim($_GET['search'] ?? '');
$status   = $_GET['status'] ?? '';
$priority = $_GET['priority'] ?? '';
$type     = $_GET['change_type'] ?? '';
$page     = max(1, (int)($_GET['page'] ?? 1));

$where = [];
$params = [];
if ($search !== '') {
    $where[] = '(title LIKE ? OR reference_no LIKE ? OR requested_by LIKE ? OR requester_email LIKE ?)';
    $like = '%' . $search . '%';
    array_push($params, $like, $like, $like, $like);
}
if (in_array($status, STATUSES, true))     { $where[] = 'status = ?';      $params[] = $status; }
if (in_array($priority, PRIORITIES, true)) { $where[] = 'priority = ?';    $params[] = $priority; }
if (in_array($type, TYPES, true))          { $where[] = 'change_type = ?'; $params[] = $type; }
$sqlWhere = $where ? 'WHERE ' . implode(' AND ', $where) : '';

/* ----- count + page ----- */
$st = db()->prepare("SELECT COUNT(*) FROM change_requests $sqlWhere");
$st->execute($params);
$total = (int)$st->fetchColumn();
$pages = max(1, (int)ceil($total / PER_PAGE));
$page = min($page, $pages);
$offset = ($page - 1) * PER_PAGE;

$st = db()->prepare("SELECT * FROM change_requests $sqlWhere ORDER BY id ASC LIMIT " . PER_PAGE . " OFFSET $offset");
$st->execute($params);
$rows = $st->fetchAll();

$from = $total ? $offset + 1 : 0;
$to = $offset + count($rows);
$qs = fn(int $p) => '?' . http_build_query(array_filter(['search' => $search, 'status' => $status, 'priority' => $priority, 'change_type' => $type, 'page' => $p]));

$pageTitle = 'Change Requests';
require __DIR__ . '/includes/header.php';
?>
<div class="d-flex justify-content-between align-items-start mb-4">
    <div>
        <h2 class="fw-bold mb-0"><i class="bi bi-card-checklist me-2 text-primary"></i>Change Requests</h2>
        <p class="text-muted mb-0">Browse, filter, and manage all system and process change requests.</p>
    </div>
    <a href="create.php" class="btn btn-primary btn-lg"><i class="bi bi-plus-lg me-1"></i>Create Request</a>
</div>

<form method="get" class="card card-soft mb-4">
    <div class="card-body">
        <div class="row g-2">
            <div class="col-lg-4">
                <div class="input-group"><span class="input-group-text bg-white"><i class="bi bi-search"></i></span>
                    <input type="text" name="search" class="form-control" placeholder="Search title, ref (e.g. CR-0001), requester..." value="<?= e($search) ?>"></div>
            </div>
            <div class="col-lg-2 col-md-4">
                <select name="status" class="form-select"><option value="">All Statuses</option>
                    <?php foreach (STATUSES as $o): ?><option <?= $status === $o ? 'selected' : '' ?>><?= e($o) ?></option><?php endforeach; ?></select>
            </div>
            <div class="col-lg-2 col-md-4">
                <select name="priority" class="form-select"><option value="">All Priorities</option>
                    <?php foreach (PRIORITIES as $o): ?><option <?= $priority === $o ? 'selected' : '' ?>><?= e($o) ?></option><?php endforeach; ?></select>
            </div>
            <div class="col-lg-2 col-md-4">
                <select name="change_type" class="form-select"><option value="">All Types</option>
                    <?php foreach (TYPES as $o): ?><option <?= $type === $o ? 'selected' : '' ?>><?= e($o) ?></option><?php endforeach; ?></select>
            </div>
            <div class="col-lg-2 d-flex gap-2">
                <button class="btn btn-primary flex-fill"><i class="bi bi-funnel me-1"></i>Filter</button>
                <a href="index.php" class="btn btn-outline-secondary flex-fill"><i class="bi bi-arrow-counterclockwise me-1"></i>Reset</a>
            </div>
        </div>
    </div>
</form>

<div class="card card-soft">
    <div class="card-header bg-white d-flex justify-content-between align-items-center py-3">
        <span class="text-muted"><i class="bi bi-table me-2"></i>Records</span>
        <span class="badge text-bg-light border">Showing <?= $from ?> - <?= $to ?> of <?= $total ?> total</span>
    </div>
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead>
                <tr><th>Ref No</th><th>Title</th><th>Type</th><th>Priority</th><th>Status</th><th>Requested By</th><th>Planned Date</th><th class="text-end">Actions</th></tr>
            </thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td><a href="view.php?id=<?= (int)$r['id'] ?>" class="ref-link"><?= e($r['reference_no']) ?></a></td>
                    <td class="title-cell" title="<?= e($r['title']) ?>"><?= e($r['title']) ?></td>
                    <td><?= type_badge($r['change_type']) ?></td>
                    <td><?= priority_badge($r['priority']) ?></td>
                    <td><?= status_badge($r['status']) ?></td>
                    <td><?= e($r['requested_by']) ?><div class="small text-muted"><?= e($r['requester_email']) ?></div></td>
                    <td class="text-nowrap"><?php if ($r['planned_date']): ?><i class="bi bi-calendar3 me-1 text-muted"></i><?= e(date('d M Y', strtotime($r['planned_date']))) ?><?php else: ?>-<?php endif; ?></td>
                    <td class="text-end text-nowrap">
                        <a href="view.php?id=<?= (int)$r['id'] ?>" class="btn btn-sm btn-outline-info" title="View"><i class="bi bi-eye"></i></a>
                        <?php if (can_modify($r)): ?>
                            <a href="edit.php?id=<?= (int)$r['id'] ?>" class="btn btn-sm btn-outline-primary" title="Edit"><i class="bi bi-pencil"></i></a>
                            <form method="post" action="delete.php" class="d-inline" data-confirm="Delete <?= e($r['reference_no']) ?>? This cannot be undone.">
                                <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                                <button class="btn btn-sm btn-outline-danger" title="Delete"><i class="bi bi-trash"></i></button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$rows): ?>
                <tr><td colspan="8" class="text-center text-muted py-5"><i class="bi bi-inbox fs-3 d-block mb-2"></i>No change requests found.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if ($pages > 1): ?>
    <div class="card-footer bg-white">
        <nav><ul class="pagination mb-0 justify-content-center">
            <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>"><a class="page-link" href="<?= $qs($page - 1) ?>">&laquo; Previous</a></li>
            <?php for ($i = 1; $i <= $pages; $i++): ?>
                <li class="page-item <?= $i === $page ? 'active' : '' ?>"><a class="page-link" href="<?= $qs($i) ?>"><?= $i ?></a></li>
            <?php endfor; ?>
            <li class="page-item <?= $page >= $pages ? 'disabled' : '' ?>"><a class="page-link" href="<?= $qs($page + 1) ?>">Next &raquo;</a></li>
        </ul></nav>
    </div>
    <?php endif; ?>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
