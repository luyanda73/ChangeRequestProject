<?php
require __DIR__ . '/database.php';

if (is_logged_in()) redirect('index.php');

$error = '';
$email = '';
$flash = get_flash();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        $error = 'Please enter your email and password.';
    } else {
        $st = db()->prepare('SELECT id, full_name, email, password, role FROM users WHERE email = ?');
        $st->execute([$email]);
        $u = $st->fetch();
        if ($u && password_verify($password, $u['password'])) {
            session_regenerate_id(true);
            unset($u['password']);
            $_SESSION['user'] = $u;
            flash('success', 'Welcome back, ' . $u['full_name'] . '!');
            redirect('index.php');
        }
        $error = 'Invalid email or password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login | Change Request System</title>
    <link rel="icon" href="images/logo.svg" type="image/svg+xml">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<body class="auth-body">
<div class="auth-card card card-soft">
    <div class="card-body p-4 p-md-5">
        <div class="text-center mb-4">
            <img src="images/logo.svg" alt="" width="56" height="56">
            <h3 class="mt-3 mb-1 fw-bold">Change Request System</h3>
            <p class="text-muted mb-0">Sign in to continue</p>
        </div>
        <?php if ($flash): ?><div class="alert alert-<?= e($flash[0]) ?> py-2"><?= e($flash[1]) ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-danger py-2"><?= e($error) ?></div><?php endif; ?>
        <form method="post" novalidate>
            <?= csrf_field() ?>
            <div class="mb-3">
                <label class="form-label">Email</label>
                <div class="input-group"><span class="input-group-text"><i class="bi bi-envelope"></i></span>
                    <input type="email" name="email" class="form-control" value="<?= e($email) ?>" placeholder="you@example.com" autofocus></div>
            </div>
            <div class="mb-3">
                <label class="form-label">Password</label>
                <div class="input-group"><span class="input-group-text"><i class="bi bi-lock"></i></span>
                    <input type="password" name="password" id="password" class="form-control" placeholder="Your password">
                    <button type="button" class="btn btn-outline-secondary" id="togglePw"><i class="bi bi-eye"></i></button></div>
            </div>
            <button class="btn btn-primary w-100 py-2"><i class="bi bi-box-arrow-in-right me-1"></i>Login</button>
        </form>
        <p class="text-center mt-3 mb-0">No account? <a href="register.php">Register here</a></p>
        <div class="demo-box mt-4 small text-muted">
            <strong>Demo accounts</strong><br>
            Admin: admin@example.com / admin123<br>
            User: luyanda@example.com / user123
        </div>
    </div>
</div>
<script src="js/app.js"></script>
</body>
</html>
