<?php
// Shared create/edit form. Expects $cr (values), $errors (array), $action (url), $submitLabel.
$val = fn($k) => e($cr[$k] ?? '');
$err = fn($k) => isset($errors[$k]) ? '<div class="invalid-feedback d-block">' . e($errors[$k]) . '</div>' : '';
$inv = fn($k) => isset($errors[$k]) ? ' is-invalid' : '';
$select = function (string $name, array $options) use ($cr, $inv, $err) {
    $h = '<select name="' . $name . '" class="form-select' . $inv($name) . '">';
    foreach ($options as $o) {
        $h .= '<option value="' . e($o) . '"' . (($cr[$name] ?? '') === $o ? ' selected' : '') . '>' . e($o) . '</option>';
    }
    return $h . '</select>' . $err($name);
};
?>
<form method="post" action="<?= e($action) ?>" class="card card-soft" novalidate>
    <div class="card-body p-4">
        <?= csrf_field() ?>
        <?php if ($errors): ?>
            <div class="alert alert-danger"><i class="bi bi-exclamation-triangle me-1"></i>Please correct the highlighted fields.</div>
        <?php endif; ?>
        <div class="row g-3">
            <div class="col-md-8">
                <label class="form-label">Title <span class="text-danger">*</span></label>
                <input type="text" name="title" class="form-control<?= $inv('title') ?>" value="<?= $val('title') ?>" maxlength="150">
                <?= $err('title') ?>
            </div>
            <div class="col-md-4">
                <label class="form-label">Status <span class="text-danger">*</span></label>
                <?= $select('status', STATUSES) ?>
            </div>
            <div class="col-12">
                <label class="form-label">Description <span class="text-danger">*</span></label>
                <textarea name="description" rows="3" class="form-control<?= $inv('description') ?>"><?= $val('description') ?></textarea>
                <?= $err('description') ?>
            </div>
            <div class="col-md-6">
                <label class="form-label">Reason for change</label>
                <textarea name="reason" rows="2" class="form-control"><?= $val('reason') ?></textarea>
            </div>
            <div class="col-md-6">
                <label class="form-label">Impact analysis</label>
                <textarea name="impact_analysis" rows="2" class="form-control"><?= $val('impact_analysis') ?></textarea>
            </div>
            <div class="col-md-3">
                <label class="form-label">Change type <span class="text-danger">*</span></label>
                <?= $select('change_type', TYPES) ?>
            </div>
            <div class="col-md-3">
                <label class="form-label">Priority <span class="text-danger">*</span></label>
                <?= $select('priority', PRIORITIES) ?>
            </div>
            <div class="col-md-3">
                <label class="form-label">Requested date <span class="text-danger">*</span></label>
                <input type="date" name="requested_date" class="form-control<?= $inv('requested_date') ?>" value="<?= $val('requested_date') ?>">
                <?= $err('requested_date') ?>
            </div>
            <div class="col-md-3">
                <label class="form-label">Planned date</label>
                <input type="date" name="planned_date" class="form-control<?= $inv('planned_date') ?>" value="<?= $val('planned_date') ?>">
                <?= $err('planned_date') ?>
            </div>
            <div class="col-md-6">
                <label class="form-label">Requested by <span class="text-danger">*</span></label>
                <input type="text" name="requested_by" class="form-control<?= $inv('requested_by') ?>" value="<?= $val('requested_by') ?>" maxlength="100">
                <?= $err('requested_by') ?>
            </div>
            <div class="col-md-6">
                <label class="form-label">Requester email <span class="text-danger">*</span></label>
                <input type="email" name="requester_email" class="form-control<?= $inv('requester_email') ?>" value="<?= $val('requester_email') ?>" maxlength="150">
                <?= $err('requester_email') ?>
            </div>
        </div>
        <div class="mt-4 d-flex gap-2">
            <button type="submit" class="btn btn-primary px-4"><i class="bi bi-check-lg me-1"></i><?= e($submitLabel) ?></button>
            <a href="index.php" class="btn btn-outline-secondary">Cancel</a>
        </div>
    </div>
</form>
