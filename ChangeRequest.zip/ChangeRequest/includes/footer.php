</main>
<footer class="text-center text-muted small py-4">
    Change Request System &middot; BCA Project 2026-27 &middot; Luyanda Kunene
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/app.js"></script>
</body>
</html>
