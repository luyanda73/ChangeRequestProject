<?php
// Expects: $pageTitle (string). database.php must already be included.
$flash = get_flash();
$user = current_user();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($pageTitle ?? 'Change Requests') ?> | Change Request System</title>
    <link rel="icon" href="images/logo.svg" type="image/svg+xml">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand navbar-dark bg-dark topbar">
    <div class="container">
        <a class="navbar-brand fw-semibold" href="index.php"><img src="images/logo.svg" alt="" width="26" height="26" class="me-2">Change Request System</a>
        <ul class="navbar-nav me-auto">
            <li class="nav-item"><a class="nav-link" href="index.php"><i class="bi bi-list-ul me-1"></i>Change Requests</a></li>
        </ul>
        <?php if ($user): ?>
            <a href="create.php" class="btn btn-primary btn-sm me-3"><i class="bi bi-plus-circle me-1"></i>New Change Request</a>
            <div class="dropdown">
                <a href="#" class="text-light text-decoration-none dropdown-toggle" data-bs-toggle="dropdown">
                    <i class="bi bi-person-circle me-1"></i><?= e($user['full_name']) ?>
                    <span class="badge text-bg-secondary ms-1"><?= e(ucfirst($user['role'])) ?></span>
                </a>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="logout.php"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
                </ul>
            </div>
        <?php endif; ?>
    </div>
</nav>
<main class="container py-4">
<?php if ($flash): ?>
    <div class="alert alert-<?= e($flash[0]) ?> alert-dismissible fade show auto-dismiss" role="alert">
        <?= e($flash[1]) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>
