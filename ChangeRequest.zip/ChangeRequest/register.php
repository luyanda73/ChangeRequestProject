<?php
require __DIR__ . '/database.php';

if (is_logged_in()) redirect('index.php');

$errors = [];
$name = $email = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $pw = $_POST['password'] ?? '';
    $pw2 = $_POST['password2'] ?? '';

    if ($name === '' || mb_strlen($name) > 100) $errors['full_name'] = 'Enter your full name (max 100 characters).';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors['email'] = 'Enter a valid email address.';
    if (strlen($pw) < 6) $errors['password'] = 'Password must be at least 6 characters.';
    if ($pw !== $pw2) $errors['password2'] = 'Passwords do not match.';

    if (!$errors) {
        $st = db()->prepare('SELECT COUNT(*) FROM users WHERE email = ?');
        $st->execute([$email]);
        if ((int)$st->fetchColumn() > 0) {
            $errors['email'] = 'This email is already registered.';
        } else {
            db()->prepare('INSERT INTO users (full_name, email, password, role) VALUES (?,?,?,?)')
                ->execute([$name, $email, password_hash($pw, PASSWORD_DEFAULT), 'user']);
            flash('success', 'Account created. You can log in now.');
            redirect('login.php');
        }
    }
}
$inv = fn($k) => isset($errors[$k]) ? ' is-invalid' : '';
$err = fn($k) => isset($errors[$k]) ? '<div class="invalid-feedback">' . e($errors[$k]) . '</div>' : '';
$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Register | Change Request System</title>
    <link rel="icon" href="images/logo.svg" type="image/svg+xml">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<body class="auth-body">
<div class="auth-card card card-soft">
    <div class="card-body p-4 p-md-5">
        <div class="text-center mb-4">
            <img src="images/logo.svg" alt="" width="56" height="56">
            <h3 class="mt-3 mb-1 fw-bold">Create account</h3>
        </div>
        <form method="post" novalidate>
            <?= csrf_field() ?>
            <div class="mb-3"><label class="form-label">Full name</label>
                <input type="text" name="full_name" class="form-control<?= $inv('full_name') ?>" value="<?= e($name) ?>"><?= $err('full_name') ?></div>
            <div class="mb-3"><label class="form-label">Email</label>
                <input type="email" name="email" class="form-control<?= $inv('email') ?>" value="<?= e($email) ?>"><?= $err('email') ?></div>
            <div class="mb-3"><label class="form-label">Password</label>
                <input type="password" name="password" class="form-control<?= $inv('password') ?>"><?= $err('password') ?></div>
            <div class="mb-3"><label class="form-label">Confirm password</label>
                <input type="password" name="password2" class="form-control<?= $inv('password2') ?>"><?= $err('password2') ?></div>
            <button class="btn btn-primary w-100 py-2">Register</button>
        </form>
        <p class="text-center mt-3 mb-0">Already registered? <a href="login.php">Login</a></p>
    </div>
</div>
</body>
</html>
