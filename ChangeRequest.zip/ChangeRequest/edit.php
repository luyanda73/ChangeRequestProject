<?php
require __DIR__ . '/database.php';
require_login();

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$st = db()->prepare('SELECT * FROM change_requests WHERE id = ?');
$st->execute([$id]);
$cr = $st->fetch();
if (!$cr) { flash('danger', 'Change request not found.'); redirect('index.php'); }
if (!can_modify($cr)) { flash('danger', 'You can only edit your own requests.'); redirect('index.php'); }

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    [$errors, $data] = validate_cr($_POST);
    if (!$errors) {
        db()->prepare('UPDATE change_requests SET title=?, description=?, reason=?, impact_analysis=?, change_type=?, priority=?, status=?,
                       requested_by=?, requester_email=?, requested_date=?, planned_date=? WHERE id=?')
            ->execute([$data['title'], $data['description'], $data['reason'] ?: null, $data['impact_analysis'] ?: null, $data['change_type'],
                       $data['priority'], $data['status'], $data['requested_by'], $data['requester_email'], $data['requested_date'],
                       $data['planned_date'] ?: null, $id]);
        flash('success', $cr['reference_no'] . ' updated successfully.');
        redirect('view.php?id=' . $id);
    }
    $cr = array_merge($cr, $data);   // keep what the user typed
}

$pageTitle = 'Edit ' . $cr['reference_no'];
$action = 'edit.php?id=' . $id;
$submitLabel = 'Update Request';
require __DIR__ . '/includes/header.php';
?>
<h2 class="fw-bold mb-3"><i class="bi bi-pencil-square me-2 text-primary"></i>Edit <?= e($cr['reference_no']) ?></h2>
<?php require __DIR__ . '/includes/form.php'; ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
