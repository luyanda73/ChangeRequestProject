<?php
/**
 * database.php - configuration, database connection and helper functions.
 * Every page includes this file first.
 */
const DB_HOST = '127.0.0.1';
const DB_NAME = 'change_request_db';
const DB_USER = 'root';
const DB_PASS = '';          // Laragon default: empty password

const TYPES      = ['Standard', 'Normal', 'Emergency'];
const PRIORITIES = ['Low', 'Medium', 'High', 'Critical'];
const STATUSES   = ['Draft', 'Submitted', 'Under Review', 'Approved', 'Rejected', 'Implemented', 'Closed'];
const PER_PAGE   = 10;

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                ]
            );
        } catch (PDOException $e) {
            die('<h3>Database connection failed.</h3><p>Start MySQL in Laragon and open '
                . '<a href="install.php">install.php</a> once to create the database.</p>');
        }
    }
    return $pdo;
}

/* ---------- small helpers ---------- */
function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

function redirect(string $url): void { header('Location: ' . $url); exit; }

function flash(string $type, string $msg): void { $_SESSION['flash'] = [$type, $msg]; }

function get_flash(): ?array
{
    if (!empty($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $f;
    }
    return null;
}

/* ---------- CSRF protection ---------- */
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}
function csrf_field(): string { return '<input type="hidden" name="csrf" value="' . csrf_token() . '">'; }
function csrf_check(): void
{
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(419);
        die('Invalid or expired form token. Go back and try again.');
    }
}

/* ---------- authentication ---------- */
function is_logged_in(): bool { return !empty($_SESSION['user']); }
function current_user(): ?array { return $_SESSION['user'] ?? null; }
function is_admin(): bool { return (current_user()['role'] ?? '') === 'admin'; }

function require_login(): void
{
    if (!is_logged_in()) {
        redirect('login.php');
    }
}

/** Admin can modify everything; a normal user only the requests he/she created. */
function can_modify(array $cr): bool
{
    return is_admin() || ((int)($cr['created_by'] ?? 0) === (int)(current_user()['id'] ?? -1));
}

/* ---------- badges ---------- */
function badge(string $class, string $text): string
{
    return '<span class="badge badge-pill text-bg-' . $class . '">' . e($text) . '</span>';
}
function type_badge(string $t): string
{
    return badge(['Standard' => 'success', 'Normal' => 'primary', 'Emergency' => 'danger'][$t] ?? 'secondary', $t);
}
function priority_badge(string $p): string
{
    return badge(['Low' => 'secondary', 'Medium' => 'info', 'High' => 'warning', 'Critical' => 'danger'][$p] ?? 'secondary', $p);
}
function status_badge(string $s): string
{
    return badge([
        'Draft' => 'secondary', 'Submitted' => 'primary', 'Under Review' => 'warning',
        'Approved' => 'success', 'Rejected' => 'danger', 'Implemented' => 'info', 'Closed' => 'dark',
    ][$s] ?? 'secondary', $s);
}

/* ---------- validation of a change request ---------- */
function validate_cr(array $in): array
{
    $errors = [];
    $d = [];
    foreach (['title', 'description', 'reason', 'impact_analysis', 'requested_by', 'requester_email'] as $k) {
        $d[$k] = trim($in[$k] ?? '');
    }
    foreach (['change_type', 'priority', 'status', 'requested_date', 'planned_date'] as $k) {
        $d[$k] = trim($in[$k] ?? '');
    }

    if ($d['title'] === '') $errors['title'] = 'Title is required.';
    elseif (mb_strlen($d['title']) < 5 || mb_strlen($d['title']) > 150) $errors['title'] = 'Title must be between 5 and 150 characters.';

    if ($d['description'] === '') $errors['description'] = 'Description is required.';
    elseif (mb_strlen($d['description']) < 10) $errors['description'] = 'Description must be at least 10 characters.';

    if (!in_array($d['change_type'], TYPES, true))    $errors['change_type'] = 'Select a valid change type.';
    if (!in_array($d['priority'], PRIORITIES, true))  $errors['priority']    = 'Select a valid priority.';
    if (!in_array($d['status'], STATUSES, true))      $errors['status']      = 'Select a valid status.';

    if ($d['requested_by'] === '') $errors['requested_by'] = 'Requester name is required.';
    elseif (mb_strlen($d['requested_by']) > 100) $errors['requested_by'] = 'Name is too long (max 100).';

    if ($d['requester_email'] === '') $errors['requester_email'] = 'Email is required.';
    elseif (!filter_var($d['requester_email'], FILTER_VALIDATE_EMAIL)) $errors['requester_email'] = 'Enter a valid email address.';

    $isDate = fn($s) => ($dt = DateTime::createFromFormat('Y-m-d', $s)) && $dt->format('Y-m-d') === $s;
    if ($d['requested_date'] === '') $errors['requested_date'] = 'Requested date is required.';
    elseif (!$isDate($d['requested_date'])) $errors['requested_date'] = 'Enter a valid date.';

    if ($d['planned_date'] !== '') {
        if (!$isDate($d['planned_date'])) $errors['planned_date'] = 'Enter a valid date.';
        elseif (!isset($errors['requested_date']) && $d['planned_date'] < $d['requested_date'])
            $errors['planned_date'] = 'Planned date cannot be before the requested date.';
    }
    return [$errors, $d];
}
